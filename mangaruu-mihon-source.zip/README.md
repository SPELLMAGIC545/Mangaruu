# Mangaruu unofficial Mihon/Tachiyomi extension — EXPERIMENTAL

An experimental Kotlin source module targeting `https://mangaruu.com`. This project contains **source code only**. It is not a finished/verified APK, and it was not compiled in this environment.

## Current confidence / limitations

- Confirmed on the website: manga URLs `/m/{slug}-{id}`, chapter URLs `/c/{slug}-ch-{number}-id-{id}`, and chapter links in manga HTML. The module implements these.
- NOT confirmed: exact search endpoint or JavaScript-based image loading. Search uses an unverified `/search?q=` endpoint. It is possible that opening a chapter returns 0 images, even if manga list loads.
- Image parser first examines reader DOM images, then simple inline `images`/`pages` arrays. It intentionally does not bypass paywalls, DRM or security checks.
- A source plugin cannot fix broken/mismatched pages already hosted by a site; it can only fetch what is available.
- Unofficial extensions should be inspected before installation, as APKs have Android app permissions.

## Compile using GitHub Actions (no Android SDK setup needed on your PC)

1. Create a private or public GitHub repository and upload the contents of this directory **including** `.github/workflows/build.yml`.
2. On GitHub, open **Actions → Build Mangaruu Mihon extension → Run workflow** (or push a change under `src/`).
3. If the build succeeds, download the artifact named `mangaruu-mihon-apk`. Extract the ZIP and install the `.apk` on Android.
4. In Mihon, enable/trust the newly installed extension through the Extensions screen if prompted.
5. Test a manga **URL** in search (rather than a title) if title search does not work. First test the manga detail and chapter listing, then chapter pages.

The workflow clones Keiyoushi's latest extension source/build system, copies this module, then invokes `./gradlew :src:ja:mangaruu:assembleDebug`. Because that upstream system changes over time, compilation may require adjustments.

## Compile on Windows (PowerShell)

Requires Git, JDK 17+, Android SDK and internet access. From the extracted directory:

```powershell
.\build.ps1
```

The APK should be generated under `extensions-source/src/ja/mangaruu/build/outputs/apk/` if successful.

## File layout

- `src/ja/mangaruu/build.gradle.kts`: Keiyoushi extension module metadata
- `src/ja/mangaruu/src/.../Mangaruu.kt`: Kotlin source implementation
- `build.ps1`: Windows build helper
- `.github/workflows/build.yml`: cloud APK builder

## Evidence and provenance

Based on publicly documented Keiyoushi extension API v1.6 and public Mangaruu URL patterns as of 2026-10-28.

https://github.com/keiyoushi/extensions-source/blob/main/CONTRIBUTING.md
https://mangaruu.com/

No copyrighted manga pages or image files are included in the project.
