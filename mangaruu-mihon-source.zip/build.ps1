# Requires: Git, JDK 17+, Android SDK (ANDROID_HOME or ANDROID_SDK_ROOT), Internet.
$ErrorActionPreference = 'Stop'
$base = $PSScriptRoot
$target = Join-Path $base 'extensions-source'
if (-not (Test-Path $target)) {
    git clone --depth 1 https://github.com/keiyoushi/extensions-source.git $target
    if ($LASTEXITCODE -ne 0) { throw 'Git clone failed' }
}
$src = Join-Path $base 'src\ja\mangaruu'
$dst = Join-Path $target 'src\ja\mangaruu'
New-Item -ItemType Directory -Force (Split-Path $dst) | Out-Null
Copy-Item $src $dst -Recurse -Force
Push-Location $target
try {
    .\gradlew.bat :src:ja:mangaruu:assembleDebug --no-daemon
    if ($LASTEXITCODE -ne 0) { throw 'Gradle build failed' }
    Write-Host 'Built APK(s):'
    Get-ChildItem $dst -Filter '*.apk' -Recurse | Select-Object -ExpandProperty FullName
} finally { Pop-Location }
